# Scoreline — case study and app, on their own

The Scoreline case study (`scoreline/`) with the real app inside it (`scoreline/app/`), plus the two
things it shares with the Turinoz portfolio: the fonts (`fonts/`) and the Rive runtime (`rive/vendor/`).

- Deploy: drag this folder onto https://app.netlify.com/drop. It must be the site's root, because the
  app is built for `/scoreline/app/`. The root page sends visitors to `scoreline/`.
- Preview locally: `python -m http.server 8000` in this folder, then open http://localhost:8000/scoreline/.
- Same files as in the portfolio. On its own, the page's back arrow and "Next project" (Storm motion
  system) point at portfolio pages that are not in this folder.
- The app is scoreline-brain, branch claude/serene-ride-v3q14v (the latest
  codex/scoreline-session-4-final, af9e5c4, plus folder support), built with
  `SCORELINE_BASE=/scoreline/app/ npm run build`.
